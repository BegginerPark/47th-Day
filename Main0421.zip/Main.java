import java.util.*;


class Main {
  public static void main(String[] args) {
//     Scanner sc = new Scanner(System.in);
    // 4-33
    // Loop1: for(int i=2; i <=9; i++) {
    //   for(int j =1; j <=9; j++) {
    //     if(j ==5) 
    //       break Loop1;
    //       break;
    //       continue Loop1;
    //       continue;
    //     System.out.println(i + "*" + j + "=" + i*j);
    //   }
    //   System.out.println();
    // }

    //4-34
    // int menu = 0, num = 0;

    // outer:
    // while (true) {
    //   System.out.println("(1) square ");
    //   System.out.println("(2) square root ");
    //   System.out.println("(3) log ");
    //   System.out.println("원하는 메뉴(1~3)을 선택하세요.(종료:0)");

    //   String tmp = sc.nextLine();
    //   menu = Integer.parseInt(tmp);

    //   if(menu == 0) {
    //     System.out.println("프로그램을 종료합니다.");
    //     break;
    //   } else if (!(1 <= menu && menu <= 3)) {
    //     System.out.println("메뉴를 잘못 선택하셨습니다. (종료는 0)");
    //     continue;
    //   }

    //   for(;;) {
    //     System.out.print("계산할 값을 입력하세요.(계산종료:0, 전체 종료:99))");
    //     tmp = sc.nextLine();
    //     num = Integer.parseInt(tmp);

    //     if (num == 0)
    //       break;
    //     if (num == 99)
    //       break outer;

    //     switch(menu) {
    //       case 1:
    //         System.out.println("result = " + num*num);
    //         break;
    //       case 2:
    //         System.out.println("result = " + Math.sqrt(num));
    //         break;
    //       case 3:
    //         System.out.println("result = " + Math.log(num));
    //         break;
    //     }
    //   }
    // }

    //5-1
    // int[] score = new int[5];
    // int k = 1;

    // score[0] = 50;
    // score[1] = 60;
    // score[k+1] = 70;
    // score[3] = 80;
    // score[4] = 90;

    // int tmp = score[k+2] + score[4];

    // for(int i= 0; i < 5; i++) {
    //     System.out.printf("score[%d]:%d%n", i,score[i]);
    // }
    // System.out.printf("tmp:%d%n", tmp);
    // System.out.printf("score[%d]:%d%n", 7,score[7]);

    //5-2
    // int[] iArr1 = new int[10];
    // int[] iArr2 = new int[10];
    // // int[] iArr3 = new int[] {100, 95, 80, 70, 60};
    // int[] iArr3 = {100, 95, 80, 70, 60};
    // char[] chArr = {'a','b','c','d'};

    // for (int i = 0; i < iArr1.length; i++) {
    //   iArr1[i] = i + 1;
    // }

    // for (int i = 0; i < iArr2.length; i++) {
    //   iArr2[i] = (int) (Math.random()*10) +1;
    // }

    // for(int i = 0; i < iArr1.length; i++) {
    //   System.out.print(iArr1[i] + ",");
    // }

    // System.out.println();
    // System.out.println(Arrays.toString(iArr2));
    // System.out.println(Arrays.toString(iArr3));
    // System.out.println(Arrays.toString(chArr));
    // System.out.println(iArr3);
    // System.out.println(chArr);


    //5-3
    // int[] arr = new int[5];

    // // 배열 arr에 1~5까지 저장한다.
    // for(int i = 0; i <arr.length; i++)
    //   arr[i] = i + 1;

    // System.out.println("[변경전]");
    // System.out.println("arr.length:" + arr.length);
    // for (int i = 0; i < arr.length; i++)
    //   System.out.println("arr["+i+"]:" + arr[i]);

    // int[] tmp = new int[arr.length*2];

    // //배열 arr에 저장된 값들을 배열 tmp에 복사한다.
    // for(int i = 0; i < arr.length; i++)
    //   tmp[i] = arr[i];

    // arr = tmp; // tmp 에 저장된 값을 arr에 저장한다.

    // System.out.println("[변경후]");
    // System.out.println("arr.length:" + arr.length);
    //  for (int i = 0; i < arr.length; i++)
    //   System.out.println("arr["+i+"]:" + arr[i]);


    //5-4
    // char[] abc = {'A','B','C','D'};
    // char[] num = {'0','1','2','3','4','5','6','7','8','9'};
    // System.out.println(abc);
    // System.out.println(num);

    // // 배열 abc 와 num을 붙여서 하나의 배열(result)로 만든다.
    // char[] result = new char[abc.length + num.length];
    // System.arraycopy(abc, 0, result, 0, abc.length);
    // System.arraycopy(num, 0, result, abc.length, num.length);
    // System.out.println(result);

    // // 배열 abc을 배열 num의 첫 번째 위치부터 배열 abc의 길이만큼 복사
    // System.arraycopy(abc, 0, num, 0, abc.length);
    // System.out.println(num);
    
    // // number의 인덱스 6 위치에 3개를 복사.
    // System.arraycopy(abc, 0, num, 6, 3);
    // System.out.println(num);


    //5-11
    // int[] numArr = new int[10];
    // int[] counter = new int[10];

    // for(int i = 0; i < numArr.length; i++) {
    //   numArr[i] = (int) (Math.random()* 10);
    //   System.out.print(numArr[i]);
    // }
    // System.out.println();

    // for(int i = 0; i < numArr.length; i++) {
    //   counter[numArr[i]]++;
    // }

    // for(int i = 0; i < numArr.length; i++) {
    //   System.out.println(i + "의 개수 : " + counter[i]);
    // }

    //5-12
    // String[] names = {"Kim","Park","Yi"};

    // for(int i = 0; i < names.length; i++)
    //   System.out.println("names["+i+"]:" + names[i]);

    // String tmp = names[2];
    // System.out.println("tmp:" + tmp);
    // names[0] = "Yu";

    // for(String str : names)
    //   System.out.println(str);

    //5-14
    // String src = "ABCDE";

    // for(int i = 0; i < src.length(); i++) {
    //   char ch = src.charAt(i);
    //   System.out.println("src.charAt("+i+"):" + ch);
    // }

    // char[] chArr = src.toCharArray();

    // System.out.println(chArr);


    // // 5-15
    // String source = "SOSHELP";
    // String[] morse = {".-", "-...", "-.-.", "-..", ".", 
    //                   "..-.", "--.", "....", "..", ".---",
    //                   "-.-", ".-..", "--", "-.", "---",
    //                   ".--.", "--.-", ".-.", "...", "-", "..-",
    //                   "...-",".--", "-..-", "-.--", "--.."};

    // String result = "";

    // for(int i = 0; i < source.length();i++) {
    //   result += morse[source.charAt(i)-'A'];
    // }
    // System.out.println("source:" + source);
    // System.out.println("morse:" + result);


    //6-2
    // class Tv {
    //   String color;
    //   boolean power;
    //   int channel;

    //   void power() {power = !power; }
    //   void channelUp() { ++channel; }
    //   void channelDown() { --channel; }
    // }

    // class TvTest2 {
    //   public static void main(String args[]) {
    //     Tv t1 = new Tv();
    //     Tv t2 = new Tv();
    //     System.out.println("t1의 channel값은 " + t1.channel + " 입니다.");
    //     System.out.println("t2의 channel값은 " + t2.channel + " 입니다.");

    //     t1.channel = 7;
    //     System.out.println("t1의 channel값을 7로 변경하였습니다.");

    //     System.out.println("t1의 channel값은 " + t1.channel + " 입니다.");
    //     System.out.println("t2의 channel값은 " + t2.channel + " 입니다.");
    //   }
    // }

    System.out.println("Card.width = " + Card.width);
    System.out.println("Card.height = " + Card.height);

    Card c1 = new Card();
    c1.kind = "Heart";
    c1.number = 7;

    Card c2 = new Card();
    c2.kind = "Spade";
    c2.number = 4;

    System.out.println("c1은 " + c1.kind + ", " + c1.number + "이며, 크기는 (" + c1.width + ", " + c1.height + ")");
    System.out.println("c2은 " + c2.kind + ", " + c2.number + "이며, 크기는 (" + c2.width + ", " + c2.height + ")");

    System.out.println("c1의 width와 height를 각각 50, 80 으로 변경합니다.");
    c1.width = 50;
    c1.height = 80;

    System.out.println("c1은 " + c1.kind + ", " + c1.number + "이며, 크기는 (" + c1.width + ", " + c1.height + ")");
    System.out.println("c2은 " + c2.kind + ", " + c2.number + "이며, 크기는 (" + c2.width + ", " + c2.height + ")");
  }
}

class Card {
  String kind;
  int number;
  static int width = 100;
  static int height = 250;
}